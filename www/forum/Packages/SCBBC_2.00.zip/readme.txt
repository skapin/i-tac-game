This MOD adds the ability to create custom BBCode for your forum.  It will show up as a tab in "Features and Options".

To add a button to a custom tag, enable the "Add button" option for the tag, and upload tagname.gif (where "tagname" is the tag name) in the Themes/default/images/bbc directory.  The image should be a 23 x 22 GIF with transparent background.

As always, I'm open to feedback and improvement ideas.


Changelog:

2.00 (Feb 04, 2007)
- Major rewrite.
- New settings interface.
- Support for parsing inside tags (nested tags).
- Support for different tags with the same name.
- Some other smaller stuff.

1.02 (Jan 12, 2007)
- Fixed bug from 1.01 where buttons didn't close some tags.

1.01 (Jan 12, 2007)
- Button support.

1.00 (Jan 10, 2007)
- Initial release.