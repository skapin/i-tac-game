Thank you for Using Single PM Mod.
This Mod Allows you to view a Single Personal Message in Your Personal Messages.
To use click the Subject link and be taken to the that PM and have it displayed Only.

To Disable the messages from showing while in a folder (not viewing a PM) go to Admin -> Features and Options
and Check: Enable Single Personal Message View

Version 1.3
! Single Messages where not following sort order.
+ Added Dutch language Support thanks to goofyboy
+ Added English-UTF8 Support
+ Added XML style sheets to .xml files for manual installs
! Properly Packaged file

Version 1.2
! Updated to work with 1.1.1-1.1.99
! Added Russian UTF-8 Support thanks to Chapaev

Version 1.1b
! Updated For 1.1 Final

Version 1.1
! needed a check to set the setting temporally if it had never been set before.
! needed to correctly check the input when it was set to the context variable.

Version 1.0b
! Put variables into context 

Version 1.0
! Release

Russian UTF-8 Support credits:
Переведен на русский (UTF8): Kazintsev N. A. <smfmods@molod.ru>