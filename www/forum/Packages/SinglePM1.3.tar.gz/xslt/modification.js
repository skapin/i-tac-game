// JavaScript file for SMF Modification XSLT file
// $Revision$ - $Date$

// SMF variables
smfVars = 
[
	{
		'variable': '$sourcedir',
		'value': 'Sources'
	},
	{
		'variable': '$themedir',
		'value': 'Themes/default'
	},
	{
		'variable': '$themesdir',
		'value': 'Themes/default'
	},
	{
		'variable': '$languagedir',
		'value': 'Themes/default/languages'
	},
	{
		'variable': '$languagesdir',
		'value': 'Themes/default/languages'
	},
	{
		'variable': '$boarddir',
		'value': ''
	}
];
// Once the page has loaded, we need to initialise.
function modification_init()
{
	// Replace references to common SMF directories.
	// Yeah, this is a little ugly (and uses JavaScript!), but I could not think
	// of a proper way to do this in XSLT...
	
	$('content').getElements('h2').forEach(
		function(id)
		{
			// Loop through all replacements
			smfVars.forEach(
				function(smfVar)
				{
					// Replace any occurance of this variable with its replacement
					id.innerHTML = id.innerHTML.replace(smfVar.variable, '<b title="' + smfVar.variable + '">' + smfVar.value + '</b>');
				}
			);
		}
	);
}

window.addEvent('domready', modification_init);
