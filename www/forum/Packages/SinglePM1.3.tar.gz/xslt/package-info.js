// JavaScript file for Package-Info XSLT file
// $Revision$ - $Date$

// Once the page has loaded, initialise the Package-Info page.
function packageInfo_init()
{
	// Make all sections show first div, and hide the rest.
	switchDiv('install', $('install').getElement('div'));
	switchDiv('uninstall', $('uninstall').getElement('div'));
	
	// Hide all upgrades
	hideDivs('upgrade');
	
	// Load the versions into the upgrade list.
	// For upgrade versions, have the "from" version only appear once, even
	// if there's multiple instances of it (eg. multiple SMF versions).
	var temp = [];
	
	// Loop through all available upgrades.
	upgrades.forEach(
		function(upgrade)
		{
			// Has this version already been added?
			if (!temp.contains(upgrade.from))
			{
				// Add this version to the list
				addToSelectBox('upgrade_version', upgrade.from, upgrade.from);
				// And add it to the array, so we don't add it again.
				temp.include(upgrade.from);
			}
		}
	);
}

// Hide all divs in a particular container div
function hideDivs(parent)
{
	$(parent).getElements('div').forEach(
		function(id)
		{
			// Hide this div.
			id.setStyle('display', 'none');
		}
	);
}

// "Switch" a div. Hide all the divs in element with ID of 'parent' parameter,
// and then show the element with ID of the 'id' parameter.
function switchDiv(parent, id)
{
	// Hide all divs in the parent
	hideDivs(parent);
	// Show the div we want.
	try
	{
		$(id).setStyle('display', '');
	}
	catch (err)
	{
		alert('"' + id + '" was not found!');
	}
}

// Choose a version to upgrade from. This shows all the SMF versions that
// the chosen upgrade is compatible with.
// from = Version you're upgrading from.
function switchUpgrade(from)
{
	var first_upgrade = true;
	
	// Clear the SMF version dropdown.
	for (i = $('upgrade_smfversion').options.length - 1; i >= 0; i--)
	{
		$('upgrade_smfversion').remove(i);
	}
	
	// If from is "-1", it means they chose the "[Choose a version]" option.
	// Hide all upgrades, and return
	if (from == -1)
	{
		hideDivs('upgrade');
		return false;
	}
	
	// Loop through all available upgrades.
	upgrades.forEach(
		function(upgrade)
		{
			// Is this a value we want?
			if (upgrade.from == from)
			{
				// Is this the first one? Show this div.
				if (first_upgrade)
				{
					switchDiv('upgrade', upgrade.id);
					first_upgrade = false;
				}

				// No SMF version?
				if (upgrade.smf_for == 0)
					addToSelectBox('upgrade_smfversion', 'Any other version', upgrade.id);
				else
					addToSelectBox('upgrade_smfversion', upgrade.smf_for, upgrade.id);
			}
		}
	);
}

// Add an option to a select box.
function addToSelectBox(selectbox, label, value)
{
	try
	{
		$(selectbox).add(new Option(label, value), null);
	}
	catch (err)
	{
		// As usual, IE does things differently...
		$(selectbox).add(new Option(label, value));
	}
}

window.addEvent('domready', packageInfo_init);
